import csv
from pathlib import Path

from app import FIELDS, fallback_cases, write_csv


def test_fallback_creates_cases_with_required_fields():
    cases = fallback_cases("Users can sign in with email and password")
    assert len(cases) >= 3
    assert all(set(FIELDS) == set(case.keys()) for case in cases)
    assert cases[0]["id"] == "TC-001"


def test_csv_writer_round_trips(tmp_path: Path):
    cases = fallback_cases("Users can upload a profile photo")
    output = tmp_path / "cases.csv"
    write_csv(cases, output)
    with output.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert len(rows) == len(cases)
    assert rows[0]["title"] == cases[0]["title"]
