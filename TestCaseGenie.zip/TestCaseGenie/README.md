# TestCaseGenie 🧪

**An open-source, AI-assisted test-case starter generator for software QA.** Turn a plain-English requirement into editable test cases and export them to CSV. It can use a local Gemma model through [Ollama](https://ollama.com/) or run with rule-based templates when AI is not available.

> This is a learning/demo project. Always review generated cases for accuracy, security, and completeness before using them in production testing.

## Why this project?

- Demonstrates practical QA thinking: positive, negative, boundary, and recovery scenarios.
- Uses an open-source Google Gemma model locally through Ollama (optional).
- Exports a CSV that can be opened in Excel or imported into many test-management workflows.
- Does not send requirements to a hosted API; the AI option calls your local Ollama service.
- Includes tests and a sample requirement so contributors can try it quickly.

## Requirements

- Python 3.10 or newer
- Optional AI mode: [Ollama](https://ollama.com/) installed and running, with a Gemma model downloaded

## Quick start (no AI setup needed)

```bash
git clone https://github.com/YOUR-USERNAME/TestCaseGenie.git
cd TestCaseGenie
python3 app.py --file sample_requirement.txt --no-ai
```

This creates `test_cases.csv` in the current directory.

Or pass a requirement directly:

```bash
python3 app.py "A user can sign in with a valid email and password" --no-ai
```

## Optional: use Gemma locally

1. Install Ollama from [ollama.com](https://ollama.com/).
2. Download a Gemma model. For example:

   ```bash
   ollama pull gemma3:4b
   ```

3. Ensure Ollama is running, then run:

   ```bash
   python3 app.py --file sample_requirement.txt --model gemma3:4b
   ```

If Ollama is unavailable or returns an invalid response, the app automatically falls back to rule-based templates.

## Run tests

```bash
python3 -m pip install -r requirements.txt
python3 -m pytest
```

## Example output fields

| Field | Description |
|---|---|
| `id` | Stable test-case identifier for this generated batch |
| `title` | Short scenario name |
| `preconditions` | What must be true before execution |
| `steps` | Actionable test steps |
| `expected_result` | Expected behavior |
| `priority` | Suggested priority; review before use |
| `type` | Scenario category, such as Positive or Boundary |

## Current limitations

- Generated cases are suggestions, not proof of complete requirement coverage.
- The rule-based fallback is intentionally generic.
- The local model may produce incorrect or incomplete cases; review its output.
- This first version is a command-line tool; a web interface and coverage mapping could be future improvements.

## Ideas for contributors

- Add JSON export and a requirement-to-test traceability report.
- Add a small web UI with Streamlit or Flask.
- Add requirement parsing for acceptance criteria and explicit edge cases.
- Add CI with GitHub Actions and a test coverage badge.
- Add support for other local models and structured output validation.

## Contributing

Issues and pull requests are welcome. For a first contribution, improve one test, add an example requirement, or improve the CSV output documentation.

## License

MIT — see [LICENSE](LICENSE).
