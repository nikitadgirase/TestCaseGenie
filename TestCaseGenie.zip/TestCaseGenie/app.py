#!/usr/bin/env python3
"""TestCaseGenie: generate starter software test cases from a requirement.

Uses a local Ollama model (Gemma recommended) when available. If Ollama is
not running, it creates a small rule-based set so the tool remains usable.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

OLLAMA_URL = "http://localhost:11434/api/generate"
FIELDS = ["id", "title", "preconditions", "steps", "expected_result", "priority", "type"]


def fallback_cases(requirement: str) -> list[dict[str, str]]:
    """Return generic, editable cases when no local AI model is available."""
    topic = requirement.strip().rstrip(".") or "the feature"
    return [
        {
            "id": "TC-001", "title": f"Verify successful use of {topic}",
            "preconditions": "The application is available and the user has valid input.",
            "steps": f"1. Open the relevant screen or workflow.\n2. Provide valid input for: {topic}.\n3. Submit or continue.",
            "expected_result": "The operation completes successfully and the result matches the requirement.",
            "priority": "High", "type": "Positive",
        },
        {
            "id": "TC-002", "title": f"Verify invalid input handling for {topic}",
            "preconditions": "The relevant screen or workflow is available.",
            "steps": "1. Open the relevant screen or workflow.\n2. Provide missing, malformed, or invalid input.\n3. Submit or continue.",
            "expected_result": "The application handles the invalid input safely and displays a clear validation message.",
            "priority": "High", "type": "Negative",
        },
        {
            "id": "TC-003", "title": f"Verify boundary conditions for {topic}",
            "preconditions": "The valid input limits or constraints are known.",
            "steps": "1. Test values at the minimum and maximum allowed limits.\n2. Test values just outside those limits.",
            "expected_result": "Boundary values are handled according to the requirement, without crashes or incorrect results.",
            "priority": "Medium", "type": "Boundary",
        },
        {
            "id": "TC-004", "title": f"Verify error recovery for {topic}",
            "preconditions": "The relevant workflow is available.",
            "steps": "1. Start the workflow.\n2. Simulate an interruption or recoverable error.\n3. Retry the operation.",
            "expected_result": "The application reports the error clearly and allows safe recovery where appropriate.",
            "priority": "Medium", "type": "Recovery",
        },
    ]


def ask_ollama(requirement: str, model: str = "gemma3:4b", timeout: int = 90) -> list[dict[str, str]]:
    """Ask a local Ollama model for structured test cases."""
    prompt = f'''You are a senior software QA engineer. Create 4 useful test cases for this requirement:
"""{requirement}"""
Return ONLY a valid JSON array. Each item must have these string keys: title, preconditions, steps, expected_result, priority, type.
Use concise, actionable steps. Include positive, negative, and boundary coverage where relevant. Do not invent product-specific details absent from the requirement.'''
    payload = json.dumps({"model": model, "prompt": prompt, "stream": False, "format": "json"}).encode("utf-8")
    request = urllib.request.Request(OLLAMA_URL, data=payload, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        result = json.loads(response.read().decode("utf-8"))
    raw = result.get("response", "")
    parsed: Any = json.loads(raw)
    if isinstance(parsed, dict):
        parsed = parsed.get("test_cases", parsed.get("cases", []))
    if not isinstance(parsed, list) or not parsed:
        raise ValueError("The model did not return a non-empty JSON array.")
    cleaned: list[dict[str, str]] = []
    for index, item in enumerate(parsed, start=1):
        if not isinstance(item, dict):
            continue
        cleaned.append({
            "id": f"TC-{index:03d}",
            "title": str(item.get("title", "Untitled test case")),
            "preconditions": str(item.get("preconditions", "None specified")),
            "steps": str(item.get("steps", "Review the requirement and execute the scenario.")),
            "expected_result": str(item.get("expected_result", "Actual behavior matches the requirement.")),
            "priority": str(item.get("priority", "Medium")),
            "type": str(item.get("type", "Functional")),
        })
    if not cleaned:
        raise ValueError("No usable test cases were returned by the model.")
    return cleaned


def generate_cases(requirement: str, use_ai: bool = True, model: str = "gemma3:4b") -> tuple[list[dict[str, str]], str]:
    if use_ai:
        try:
            cases = ask_ollama(requirement, model=model)
            return cases, f"AI-generated with local Ollama model: {model}"
        except (urllib.error.URLError, TimeoutError, ValueError, json.JSONDecodeError, KeyError) as exc:
            return fallback_cases(requirement), f"Rule-based fallback used (local model unavailable or response invalid: {exc})"
    return fallback_cases(requirement), "Rule-based templates used"


def write_csv(cases: list[dict[str, str]], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(cases)


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate starter test cases from a software requirement.")
    parser.add_argument("requirement", nargs="?", help="Requirement text in quotes")
    parser.add_argument("--file", type=Path, help="Read requirement text from a file")
    parser.add_argument("--output", type=Path, default=Path("test_cases.csv"), help="Output CSV path (default: test_cases.csv)")
    parser.add_argument("--model", default="gemma3:4b", help="Ollama model name (default: gemma3:4b)")
    parser.add_argument("--no-ai", action="store_true", help="Use rule-based templates only")
    args = parser.parse_args()

    if args.file:
        requirement = args.file.read_text(encoding="utf-8").strip()
    elif args.requirement:
        requirement = args.requirement.strip()
    else:
        parser.error("Provide requirement text or use --file requirements.txt")
    if not requirement:
        parser.error("Requirement text cannot be empty")

    cases, mode = generate_cases(requirement, use_ai=not args.no_ai, model=args.model)
    write_csv(cases, args.output)
    print(f"{len(cases)} test cases saved to: {args.output}")
    print(f"Generation mode: {mode}")
    print("Please review and adapt generated cases before using them in a real test plan.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
